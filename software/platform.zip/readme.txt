SYSTEM REQUIREMENTS:
OS: Windows 10/11
GPU: DirectX 12
CPU: ~2013-2015 onwards (AVX instruction flag in CPUID)

INSTALLATION:
extract platform.exe and imgui.ini into the same folder

BASIC USAGE:
some UI panels may be occluded when the program starts; they can be repositioned by dragging to reveal others

click the note slider in the main UI panel to trigger a note or click hold to use as a drone
each osc ui module controls a discrete oscillator
there are 8 voices with 8 oscillators each
change the voice mode to manual to control all 8 voices directly

CORE PARAMETERS:
mix level controls the oscillator's output volume
when the program starts this is set to zero for all oscillators except osc #0

freq ratio and freq offset control the oscillator's frequency relative to the note
when the program starts these are set to a pleasant harmony
freq offset can be used to apply temporary adjustments

shape morphs the wave between sine, triangle, saw, and square

ENVELOPES:
delay, attack, decay, sustain, and release control the envelope for the oscillator
this controls the volume of the oscillator as note is clicked or held, and after it is released

low attack, decay, and release values create short, sharp sounds
high values create slow, long sounds that can be overlapped if played in succession
sustain controls how quiet the note becomes after it has been held for a duration

MODULATION:
the 8 receive sliders at the top of each module control modulation inputs
the 8 send sliders the bottom of each module control modulation outputs
each send slider corresponds to an receive slider on another module and vise-versa

any oscillator may modulate any other oscillator, including itself, by frequency modulation
send level may be used to increase or decrease the strength of modulation outputs, but as no effect on inputs

TIPS:
normally you will not be able to hear the effects of modulation unless the modulated oscillator has mix level > 0

any numeric value can be precisely input by CTRL-click on the slider
this also allows you to move parameters outside of the normal range

low frequency oscillators normally send lower modulation effects
you can create LFOs by setting the frequency ratio of an oscillator very low and using CTRL-click to set send level to a very high amount

the render panel can be used to add background graphics

you cannot currently save your programs

MISC:
spout compatibility has been disabled in this version

ISSUES:
marc.gluyas@gmail.com
if the program fails to launch please run from the terminal and include any output messages
feature requests welcome
